extern int yyparse();

int main() {
    yyparse();
    return 0;
}
